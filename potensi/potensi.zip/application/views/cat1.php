<table width="900" cellpadding="0" cellspacing="0" border="0" align="center">
    <tr>
        <td width="300">
            <table width="160" cellpadding="0" cellspacing="0" align="center" border="1">
                <tr>
                    <td>
                        <table width="160" cellpadding="0" cellspacing="0" align="center" border="0">
                            <tr>
                                <td>
                                    <div align="center">
                                        <img width="160" height="160" alt="" src="<?php echo base_url() . 'images/masjid.png';?>" />
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td width="300">
                                    <table width="160" cellpadding="0" cellspacing="0" align="center">
                                        <tr>
                                            <td bgcolor="#2F89B6">
                                                <div class="noline">
                                                    <a href="<?php
                                                        if($this->session->userdata('login')==TRUE){
                                                            echo base_url() . 'index.php/aset/view/1A';
                                                        }else{
                                                            echo '#';
                                                        }
                                                        ?>">

                                                        <div class="kategori"><h4>Masjid<br />
                                                            <?php
                                                                $numRec = $this->Aset_model->countAsetByKodeJenis('1A');
                                                                echo $numRec;
                                                            ?>
                                                            </h4>
                                                        </div>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td width="300">
            <table width="160" cellpadding="0" cellspacing="0" align="center" border="1">
                <tr>
                    <td>
                        <table width="160" cellpadding="0" cellspacing="0" align="center" border="0">
                            <tr>
                                <td>
                                    <div align="center">
                                        <img width="160" height="160" alt="" src="<?php echo base_url() . 'images/masjid.png';?>" />
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td width="300">
                                    <table width="160" cellpadding="0" cellspacing="0" align="center">
                                        <tr>
                                            <td bgcolor="#2F89B6">
                                                <div class="noline">
                                                    <a href="<?php
                                                        if($this->session->userdata('login')==TRUE){
                                                            echo base_url() . 'index.php/aset/view/1B';
                                                        }else{
                                                            echo '#';
                                                        }
                                                        ?>">

                                                        <div class="kategori"><h4>Musholla<br />
                                                            <?php
                                                                $numRec = $this->Aset_model->countAsetByKodeJenis('1B');
                                                                echo $numRec;
                                                            ?>
                                                            </h4>
                                                        </div>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td width="300">
            <table width="160" cellpadding="0" cellspacing="0" align="center" border="1">
                <tr>
                    <td>
                        <table width="160" cellpadding="0" cellspacing="0" align="center" border="0">
                            <tr>
                                <td>
                                    <div align="center">
                                        <img width="160" height="160" alt="" src="<?php echo base_url() . 'images/nopics.png';?>" />
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td width="300">
                                    <table width="160" cellpadding="0" cellspacing="0" align="center">
                                        <tr>
                                            <td bgcolor="#2F89B6">
                                                &nbsp;
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="300">
            <table width="160" cellpadding="0" cellspacing="0" align="center" border="1">
                <tr>
                    <td>
                        <table width="160" cellpadding="0" cellspacing="0" align="center" border="0">
                            <tr>
                                <td>
                                    <div align="center">
                                        <img width="160" height="160" alt="" src="<?php echo base_url() . 'images/nopics.png';?>" />
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td width="300">
                                    <table width="160" cellpadding="0" cellspacing="0" align="center">
                                        <tr>
                                            <td bgcolor="#2F89B6">
                                                &nbsp;
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td width="300">
            <table width="160" cellpadding="0" cellspacing="0" align="center" border="1">
                <tr>
                    <td>
                        <table width="160" cellpadding="0" cellspacing="0" align="center" border="0">
                            <tr>
                                <td>
                                    <div align="center">
                                        <img width="160" height="160" alt="" src="<?php echo base_url() . 'images/nopics.png';?>" />
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td width="300">
                                    <table width="160" cellpadding="0" cellspacing="0" align="center">
                                        <tr>
                                            <td bgcolor="#2F89B6">
                                                &nbsp;
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td width="300">
            <table width="160" cellpadding="0" cellspacing="0" align="center" border="1">
                <tr>
                    <td>
                        <table width="160" cellpadding="0" cellspacing="0" align="center" border="0">
                            <tr>
                                <td>
                                    <div align="center">
                                        <img width="160" height="160" alt="" src="<?php echo base_url() . 'images/nopics.png';?>" />
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td width="300">
                                    <table width="160" cellpadding="0" cellspacing="0" align="center">
                                        <tr>
                                            <td bgcolor="#2F89B6">
                                                &nbsp;
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="300">
            <table width="160" cellpadding="0" cellspacing="0" align="center" border="1">
                <tr>
                    <td>
                        <table width="160" cellpadding="0" cellspacing="0" align="center" border="0">
                            <tr>
                                <td>
                                    <div align="center">
                                        <img width="160" height="160" alt="" src="<?php echo base_url() . 'images/nopics.png';?>" />
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td width="300">
                                    <table width="160" cellpadding="0" cellspacing="0" align="center">
                                        <tr>
                                            <td bgcolor="#2F89B6">
                                                &nbsp;
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td width="300">
            <table width="160" cellpadding="0" cellspacing="0" align="center" border="1">
                <tr>
                    <td>
                        <table width="160" cellpadding="0" cellspacing="0" align="center" border="0">
                            <tr>
                                <td>
                                    <div align="center">
                                        <img width="160" height="160" alt="" src="<?php echo base_url() . 'images/nopics.png';?>" />
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td width="300">
                                    <table width="160" cellpadding="0" cellspacing="0" align="center">
                                        <tr>
                                            <td bgcolor="#2F89B6">
                                                &nbsp;
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
        <td width="300">
            <table width="160" cellpadding="0" cellspacing="0" align="center" border="1">
                <tr>
                    <td>
                        <table width="160" cellpadding="0" cellspacing="0" align="center" border="0">
                            <tr>
                                <td>
                                    <div align="center">
                                        <img width="160" height="160" alt="" src="<?php echo base_url() . 'images/nopics.png';?>" />
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td width="300">
                                    <table width="160" cellpadding="0" cellspacing="0" align="center">
                                        <tr>
                                            <td bgcolor="#2F89B6">
                                                &nbsp;
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>