<?php
    switch($cat){
        case "1":
            $this->load->view('cat1');
            break; 
        case "2":
            $this->load->view('cat2');
            break;
        case "3":
            $this->load->view('cat3');
            break;
        case "4":
            $this->load->view('cat4');
            break;
        case "5":
            $this->load->view('cat5');
            break;
        case "6":
            $this->load->view('cat6');
            break;
        case "7":
            $this->load->view('cat7');
            break;
        case "8":
            $this->load->view('cat8');
            break;
    }
?>