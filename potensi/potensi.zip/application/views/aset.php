<table width="900" cellpadding="0" cellspacing="0" align="center" border="0">
    <tr>
        <td width="400" valign="top">
            <table width="100%" cellpadding="10" cellspacing="10" border="0">
                <tr>
                    <td width="25%" align="center">
                        <a href="http://localhost/potensi/index.php/main/view/1">
                            <img src="#" alt="Tempat Ibadah"><br />
                            <span>Tempat Ibadah<br />
                                <?php echo $cat1;?></span></a>
                    </td>
                    <td width="25%" align="center">
                        <a href="http://localhost/potensi/index.php/main/view/2">
                            <img src="#" alt="Pendidikan"><br />
                            <span>Pendidikan <br />
                                <?php echo $cat2;?></span></a>
                    </td>
                    <td width="25%" align="center">
                        <a href="http://localhost/potensi/index.php/main/view/3">
                            <img src="#" alt="Sosial"><br />
                            <span>Sosial <br />
                                <?php echo $cat3;?></span></a>
                    </td>
                    <td width="25%" align="center">
                        <a href="http://localhost/potensi/index.php/main/view/4">
                            <img src="#" alt="Perkantoran"><br />
                            <span>Perkantoran <br />
                                <?php echo $cat4;?></span></a>
                    </td>
                </tr>
                <tr>
                    <td width="25%" align="center">
                        <a href="http://localhost/potensi/index.php/main/view/5">
                            <img src="#" alt="Kesehatan"><br />
                            <span>Kesehatan <br />
                                <?php echo $cat5;?></span></a>
                    </td>
                    <td width="25%" align="center">
                        <a href="http://localhost/potensi/index.php/main/view/6">
                            <img src="#" alt="Ekonomi"><br />
                            <span>Ekonomi <br />
                                <?php echo $cat6;?></span></a>
                    </td>
                    <td width="25%" align="center">
                        <a href="http://localhost/potensi/index.php/main/view/7">
                            <img src="#" alt="Media Dakwah"><br />
                            <span>Media Dakwah <br />
                                <?php echo $cat7;?></span></a>
                    </td>
                    <td width="25%" align="center">
                        <a href="http://localhost/potensi/index.php/main/view/8">
                            <img src="#" alt="Lain-lain"><br />
                            <span>Lain-lain <br />
                                <?php echo $cat8;?></span></a>
                    </td>
                </tr>
            </table>
        </td>    
        <td width="400" valign="top">
            
<h3>
    <span>Selamat Datang di Aplikasi Pemetaan Potensi Nahdlatul Ulama</span>
</h3>


        <p>Aplikasi Pemetaan Potensi Nahdlatul Ulama merupakan suatu fasilitas yang digunakan untuk mencatat semua informasi mengenai obyek atau aset yang menjadi potensi
                bagi Warga Nahdlatul Ulama yang meliputi beberapa aspek, mulai dari aspek ekonomi, sosial dan budaya.</p>
        <p>Semoga informasi yang disajikan oleh Aplikasi ini dapat menjadi acuan dalam rangka menggali dan meningkatkan manfaat dari setiap aset yang berpotensi untuk meningkatkan kemaslahatan umat khususnya warga Nahdlatul Ulama.</p>
       
        </td>
    </tr>
</table>